import { Directive, ElementRef, HostBinding, HostListener, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {

  constructor(private el: ElementRef, private renderer: Renderer2) {
    
    el.nativeElement.style.fontSize="50px";
    
   }
  //  @HostBinding("style.backgroundColor") bgColor;
  //  @HostListener('mouseenter') mouseEnter(){
  //     this.changeColor("blue");
  //     this.changesize(100);
  //     this,this.bgColor="khaki"

  //  }
  //  @HostListener('mouseleave') mouseLeave(){
  //   this.changeColor("green");
  //   this.changesize(50);
  //  }

  //  changeColor(color:string){
  //    this.el.nativeElement.style.color=color;
  //  }
  //  changesize(size:number){
  //   this.el.nativeElement.style.fontSize=`${size}px`;
  // }
  ngOnInit(){
    this.renderer.setStyle(this.el.nativeElement,'background-color','skyblue');
  
  }
   
}
