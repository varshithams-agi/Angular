import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <form class="form">
  <h2>Employee Interests Survey Form</h2>


<div class="container">
  <form action="/action_page.php">
  <div class="row">
    <div class="col-25">
      <label for="fname">enter your name</label>
    </div>
    <div class="col-75">
      <input type="text" id="fname" name="firstname">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">enter your department</label>
    </div>
    <div class="col-75">
      <input type="text" id="lname" name="lastname">
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="subject">Tell us a little about yourself:</label>
    </div>
    <div class="col-75">
      <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>
    </div>
   </div> 
  
  <div class="row">
    <div class="col-25">
      <label for="subject">Do you exercise at home?</label>
    </div>
    <div>
  <input type="radio" >
  <label for="yes">yes</label>
  </div>
  <div>
  <input type="radio">
  <label for="no">no</label>
  </div>
  
</div>
<div class="row">
    <div class="col-25">
      <label for="country">what genre of movies do you like?</label>
    </div>
    <div class="col-75">
      <select id="country" name="country">
        <option value="australia">comedy</option>
        <option value="canada">thrilling</option>
        <option value="usa">family movie</option>
      </select>
    </div>
  </div>


  <br>
  <div class="row">
    <input type="submit" value="Submit">
  </div>

</form>
  
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'proj';
  alpha="a"
  role="testing"
}
