import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exa',
  templateUrl: './exa.component.html',
  styleUrls: ['./exa.component.css']
})
export class ExaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
