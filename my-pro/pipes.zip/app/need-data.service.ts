import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NeedDataService {

  constructor() { }
  products=[
    {Gname:'football'},
    {Gname:'gloves'},
    {Gname:'golf'},
    {Gname:'blooper'}]
}
